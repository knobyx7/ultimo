**Note: for support questions, please join our [Discord server](https://discord.gg/26wMygt)**

* **I'm submitting a ...**
[ ] bug report
[ ] feature request
[ ] question about the decisions made in the repository

* **Action taken** (what you did)


* **Expected result** (what you hoped would happen)


* **Actual result** (unexpected outcome)


* **Other information** (e.g. detailed explanation, stacktraces, related issues, suggestions how to fix, links for us to have context, eg. stackoverflow, etc)
